#!/bin/sh
while true; do
  ./oracle
done
