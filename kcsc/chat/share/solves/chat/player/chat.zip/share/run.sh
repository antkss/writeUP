#!/bin/sh

while true;
do
	timeout 120 /app/chat
	sleep 10
done